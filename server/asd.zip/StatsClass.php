<?php
class StatsClass
{
    /* Class Documentation
    *
    */
    public function lastNOrders(){}

    public function lastNOrdersProduct(){}

    public function lastNOrdersCategory(){}

    public function listRangeOrders(){}

    public function listRangeOrdersProduct(){}

    public function listRangeOrdersCategory(){}

    public function pendingOrders(){}

    public function bestSellingProductsCategory(){}

    public function bestSellingCategory(){}

    
}
?>
